/**
 * @license
 * Visual Blocks Editor
 *
 * Copyright 2012 Google Inc.
 * https://blockly.googlecode.com/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Describes a code block being matched, including the sequence of statements inside it.
 * @author eric@legoaces.org (Eric Miller)
 */


Blockly.Degenerator.Sequence = function( codeString ){
	this.code = codeString
	this.unmatched = codeString
	this.statements = []
}

Blockly.Degenerator.Sequence.prototype.matched = function(match){
	var l = match.code.length
	if (this.unmatched.slice(0, l) != match.code){
		console.log('Given match that is not prefix')
	}
	this.unmatched = this.unmatched.slice(l)
	this.statements.push(match)
}

Blockly.Degenerator.Sequence.prototype.getMatch = function(){
	return new Blockly.Degenerator.Match(this.unmatched)
}

// Blockly.Degenerator.Sequence.prototype.clone = function(){ //Not really a deep clone
	// return new Blockly.Degenerator.Sequence(this.code)
// }

Blockly.Degenerator.Sequence.prototype.toBlock = function(){
	if (this.statements.length < 1) {
		console.log('error: no blocks in sequence to generate')
		return null;
	}

	var firstBlock
	var lastBlock = null

	for (var i = 0; i < this.statements.length; i++){
		var block = this.statements[i].toBlock()
		if (lastBlock == null){
			firstBlock = block
			lastBlock = block
		}else{
			block.previousConnection.connect(lastBlock.nextConnection)
			lastBlock = block
		}
	}

	return firstBlock;
}
