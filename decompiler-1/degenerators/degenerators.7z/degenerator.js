/**
 * @license
 * Visual Blocks Editor
 *
 * Copyright 2012 Google Inc.
 * https://blockly.googlecode.com/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Utility functions for generating executable code from
 * Blockly code.
 * @author eric@legoaces.org (Eric Miller)
 */
'use strict';

goog.provide('Blockly.Degenerator');

goog.require('Blockly.Block');


/**
 * Class for a code generator that translates the blocks into a language.
 * @param {string} name Language name of this generator.
 * @constructor
 */
Blockly.Degenerator = function(name) {
  this.name_ = name;
  this.ePatterns = [];
  this.RESERVED_WORDS_ = '';
};

/**
 * Category to separate generated function names from variables and procedures.
 */
Blockly.Degenerator.NAME_TYPE = 'generated_function';

/**
 * Generate code for all blocks in the workspace to the specified language.
 * @return {string} Generated code.
 */
Blockly.Degenerator.prototype.codeToWorkspace = function(code) {
  this.init()
  /* 
  code=[]
  this.init();
  var blocks = Blockly.mainWorkspace.getTopBlocks(true);
  for (var x = 0, block; block = blocks[x]; x++) {
    var line = this.blockToCode(block);
    if (goog.isArray(line)) {
      // Value blocks return tuples of code and operator order.
      // Top-level blocks don't care about operator order.
      line = line[0];
    }
    if (line) {
      if (block.outputConnection && this.scrubNakedValue) {
        // This block is a naked value.  Ask the language's code generator if
        // it wants to append a semicolon, or something.
        line = this.scrubNakedValue(line);
      }
      code.push(line);
    }
  }
  code = code.join('\n');  // Blank line between each section.
  code = this.finish(code);
  // Final scrubbing of whitespace.
  code = code.replace(/^\s+\n/, '');
  code = code.replace(/\n\s+$/, '\n');
  code = code.replace(/[ \t]+\n/g, '\n');
  return code; */
};

// The following are some helpful functions which can be used by multiple
// languages.

/**
 * Prepend a common prefix onto each line of code.
 * @param {string} text The lines of code.
 * @param {string} prefix The common prefix.
 * @return {string} The prefixed lines of code.
 */
Blockly.Degenerator.prototype.prefixLines = function(text, prefix) {
  return prefix + text.replace(/\n(.)/g, '\n' + prefix + '$1');
};

Blockly.Degenerator.prototype.expressionMatch = function(patterns, string){
	string = this.pstrip(string)
	var results = []
	for (var i = 0; i < patterns.length; i++){
		if (typeof(patterns[i]) == 'function'){
			var ret = patterns[i](string)
			if (!ret) continue
			results.push(ret)
		}else{
			var pat = patterns[i].pattern
			var match;
			match = this.patternMatch(pat[0], string)
			if (!match) continue
			results.push({match:match, bind:pat[1]})
		}
	}
	if (results.length == 0) return 'fail, no matches'
	
	var max = {bind:-1}
	for (var i = 0; i < results.length; i++){
		var res = results[i]
		if (res.bind > max.bind){
			max=res
		}
	}
	// console.log(max)
	if(typeof(max.match) == 'object'){
		for (var i = 1; i < max.match.length; i += 2){
			var ter = max.match[i]
			ter.recurse = this.expressionMatch(patterns, ter.string)
		}
	}
	
	return results, max
}

Blockly.Degenerator.prototype.pstrip = function(s){
	s = s.trim()
	if (s[0] == '(' && this.lenToMatch(s.slice(1), ')') == s.length-2){
		//Thing begins and ends with parenthesis
		s = s.slice(1, s.length-1)
		s = s.trim()
	}
	return s
}

Blockly.Degenerator.prototype.patternMatch = function(pattern, string){
	if (typeof(pattern) == 'function') return pattern(string)

	var tokens = this.tokenize(pattern)
	if (tokens.length % 2 != 1) throw Error()
	
	var j = 0
	
	for (var i = 0; i < tokens.length; i += 2){
		var t = tokens[i] //should always be string
		if (i==0){
			if (string.indexOf(t) != 0) return false //String does not start with first token!
			j += t.length
			continue
		}
		var p = tokens[i-1]
		
		p.start = j
		//console.log(string.slice(j))
		var d = this.lenToMatch(string.slice(j), t)
		if (d<0) return false
		j += d
		p.end = j
		p.string = string.slice(p.start, p.end)
		j += t.length
		//console.log(j)

		if (i == tokens.length - 1){ //Last token
			if (j != string.length){ //Last token not at end of string
				//console.log(j)
				//console.log(tokens.length)
				return false
			}
		}
		
	}
	//console.log(tokens)
	//console.log(JSON.stringify(tokens)); 
	return tokens;
	
}

Blockly.Degenerator.prototype.tokenize = function(pattern){
	var tokens = []
	
	while (true){
		var r = pattern.match(/\|block:[0-9]*~~input:[^~]*~~order:[0-9]*\|/)
		if (!r || r.length == 0 || r[0].length == 0){
			tokens.push(pattern)
			break
		}
		r = r[0]
		var i = pattern.indexOf(r)
		tokens.push(pattern.slice(0,i))
		tokens.push({k:r})
		pattern = pattern.slice(i+r.length)
	}
	return tokens
}

Blockly.Degenerator.prototype.lenToMatch = function(s, end) {
	if (end.length == 0) return s.length
	var inQuote = ''
	var inParens = []
	var i=0
	var quotes = '\'"' // " , '
	var parens = {'(':')','{':'}','[':']'}
	while (i < s.length){
		var c = s[i]
		if (inQuote){
			if (c == '\\'){ //single backslash
				i++ //Skip the next character
			}
			if (c == inQuote){
				inQuote = '' //Exit quote
			}
		}else if (inParens.length > 0){
			var p = parens[inParens[inParens.length-1]]
			if (c == p){
				inParens.pop()
			}
		}else{
			var done = s.slice(i).indexOf(end) == 0
			if (done) return i
			if (quotes.indexOf(c) >= 0){
				inQuote = c
			}
			if (c in parens){
				inParens.push(c)
			}
		}
		i++
	}
	return -1; //Thing not found
}

Blockly.Degenerator.prototype.iterNoParens = function(s, callback, nullParens) {
	if (typeof(nullParens) == 'undefined') nullParens = true
	var inQuote = ''
	var inParens = []
	var i=0
	var quotes = '\'"' // " , '
	var openers = '({['
	var closers = {'(':')','{':'}','[':']'}
	while (i < s.length){
		var c = s[i]
		if (inQuote){
			if (c == '\\'){
				i++ //Skip the next character
			}
			if (c == inQuote){
				var end = callback(i)
				if (end) return end
				inQuote = '' //Exit quote
			}
		}else if (inParens.length > 0){
			var p = closers[inParens[inParens.length-1]]
			if (c == p){
				var end = callback(i)
				if (end) return end
				inParens.pop()
			}else if (!nullParens){
				var end = callback(i)
				if (end) return end
			}
		}else{
			var end = callback(i)
			if (end) return end
			if (quotes.indexOf(c) >= 0){
				inQuote = c
			}
			if (openers.indexOf(c) >= 0){
				inParens.push(c)
			}
		}
		i++
	}
}

function testInput(blockType, test){
	// console.log(test)
	var oldV2C = Blockly.JavaScript.valueToCode
	var oldS2C = Blockly.JavaScript.statementToCode
	Blockly.JavaScript.valueToCode = function(block, input, order) {
		return '|block:'+String(block.id)+
				'~~input:'+String(input)+'~~order:'+String(order)+'|'}
	Blockly.JavaScript.statementToCode = function(block, input) {
		return '|block:'+String(block.id)+
				'~~input:'+String(input)+'|'}
			
	var block = Blockly.Block.obtain(Blockly.mainWorkspace, blockType)
	var allkeys = Object.keys(test)

	var testClone = {}
	for (var i = 0; i < allkeys.length; i++){
		testClone[allkeys[i]] = test[allkeys[i]]
		block.setFieldValue(test[allkeys[i]], allkeys[i])
	}
	var result = Blockly.JavaScript.blockToCode(block)
	block.dispose()
	Blockly.JavaScript.valueToCode = oldV2C
	Blockly.JavaScript.statementToCode = oldS2C
	return {pattern: result, block: blockType, args: testClone}
}

function testAllInputs(blockType, tests){
	if (typeof(tests) == 'undefined') tests = {}
	var allKeys = Object.keys(tests)
	var foundList = false
	for (var i = 0; i < allKeys.length; i++){
		var k = allKeys[i]
		var v = tests[k]
		if (typeof(v) == 'object'){
			foundList = true
			var results = []
			var origional = v
			for (var j = 0; j < v.length; j++){
				tests[k] = v[j]
				results = results.concat(testAllInputs(blockType, tests))
			}
			tests[k] = v
			return results
		}
	}
	if (!foundList){
		return [testInput(blockType, tests)]
	}
}
//OLD TEMPLATE BELOW

/**
 * Recursively spider a tree of blocks, returning all their comments.
 * @param {!Blockly.Block} block The block from which to start spidering.
 * @return {string} Concatenated list of comments.
 */
Blockly.Degenerator.prototype.allNestedComments = function(block) {
  var comments = [];
  var blocks = block.getDescendants();
  for (var x = 0; x < blocks.length; x++) {
    var comment = blocks[x].getCommentText();
    if (comment) {
      comments.push(comment);
    }
  }
  // Append an empty string to create a trailing line break when joined.
  if (comments.length) {
    comments.push('');
  }
  return comments.join('\n');
};

/**
 * Generate code for the specified block (and attached blocks).
 * @param {Blockly.Block} block The block to generate code for.
 * @return {string|!Array} For statement blocks, the generated code.
 *     For value blocks, an array containing the generated code and an
 *     operator order value.  Returns '' if block is null.
 */
Blockly.Degenerator.prototype.blockToCode = function(block) {
  if (!block) {
    return '';
  }
  if (block.disabled) {
    // Skip past this block if it is disabled.
    return this.blockToCode(block.getNextBlock());
  }

  var func = this[block.type];
  if (!func) {
    throw 'Language "' + this.name_ + '" does not know how to generate code ' +
        'for block type "' + block.type + '".';
  }
  // First argument to func.call is the value of 'this' in the generator.
  // Prior to 24 September 2013 'this' was the only way to access the block.
  // The current prefered method of accessing the block is through the second
  // argument to func.call, which becomes the first parameter to the generator.
  var code = func.call(block, block);
  if (goog.isArray(code)) {
    // Value blocks return tuples of code and operator order.
    return [this.scrub_(block, code[0]), code[1]];
  } else {
    return this.scrub_(block, code);
  }
};

/**
 * Generate code representing the specified value input.
 * @param {!Blockly.Block} block The block containing the input.
 * @param {string} name The name of the input.
 * @param {number} order The maximum binding strength (minimum order value)
 *     of any operators adjacent to "block".
 * @return {string} Generated code or '' if no blocks are connected or the
 *     specified input does not exist.
 */
Blockly.Degenerator.prototype.valueToCode = function(block, name, order) {
  if (isNaN(order)) {
    throw 'Expecting valid order from block "' + block.type + '".';
  }
  var targetBlock = block.getInputTargetBlock(name);
  if (!targetBlock) {
    return '';
  }
  var tuple = this.blockToCode(targetBlock);
  if (tuple === '') {
    // Disabled block.
    return '';
  }
  if (!goog.isArray(tuple)) {
    // Value blocks must return code and order of operations info.
    // Statement blocks must only return code.
    throw 'Expecting tuple from value block "' + targetBlock.type + '".';
  }
  var code = tuple[0];
  var innerOrder = tuple[1];
  if (isNaN(innerOrder)) {
    throw 'Expecting valid order from value block "' + targetBlock.type + '".';
  }
  if (code && order <= innerOrder) {
    if (order == innerOrder || (order == 0 || order == 99)) {
      // 0 is the atomic order, 99 is the none order.  No parentheses needed.
      // In all known languages multiple such code blocks are not order
      // sensitive.  In fact in Python ('a' 'b') 'c' would fail.
    } else {
      // The operators outside this code are stonger than the operators
      // inside this code.  To prevent the code from being pulled apart,
      // wrap the code in parentheses.
      // Technically, this should be handled on a language-by-language basis.
      // However all known (sane) languages use parentheses for grouping.
      code = '(' + code + ')';
    }
  }
  return code;
};

/**
 * Generate code representing the statement.  Indent the code.
 * @param {!Blockly.Block} block The block containing the input.
 * @param {string} name The name of the input.
 * @return {string} Generated code or '' if no blocks are connected.
 */
Blockly.Degenerator.prototype.statementToCode = function(block, name) {
  var targetBlock = block.getInputTargetBlock(name);
  var code = this.blockToCode(targetBlock);
  if (!goog.isString(code)) {
    // Value blocks must return code and order of operations info.
    // Statement blocks must only return code.
    throw 'Expecting code from statement block "' + targetBlock.type + '".';
  }
  if (code) {
    code = this.prefixLines(/** @type {string} */ (code), this.INDENT);
  }
  return code;
};

/**
 * The method of indenting.  Defaults to two spaces, but language generators
 * may override this to increase indent or change to tabs.
 */
Blockly.Degenerator.prototype.INDENT = '  ';

/**
 * Add one or more words to the list of reserved words for this language.
 * @param {string} words Comma-separated list of words to add to the list.
 *     No spaces.  Duplicates are ok.
 */
Blockly.Degenerator.prototype.addReservedWords = function(words) {
  this.RESERVED_WORDS_ += words + ',';
};

/**
 * This is used as a placeholder in functions defined using
 * Blockly.Degenerator.provideFunction_.  It must not be legal code that could
 * legitimately appear in a function definition (or comment), and it must
 * not confuse the regular expression parser.
 */
Blockly.Degenerator.prototype.FUNCTION_NAME_PLACEHOLDER_ = '{leCUI8hutHZI4480Dc}';
Blockly.Degenerator.prototype.FUNCTION_NAME_PLACEHOLDER_REGEXP_ =
    new RegExp(Blockly.Degenerator.prototype.FUNCTION_NAME_PLACEHOLDER_, 'g');

/**
 * Define a function to be included in the generated code.
 * The first time this is called with a given desiredName, the code is
 * saved and an actual name is generated.  Subsequent calls with the
 * same desiredName have no effect but have the same return value.
 *
 * It is up to the caller to make sure the same desiredName is not
 * used for different code values.
 *
 * The code gets output when Blockly.Degenerator.finish() is called.
 *
 * @param {string} desiredName The desired name of the function (e.g., isPrime).
 * @param {!Array.<string>} code A list of Python statements.
 * @return {string} The actual name of the new function.  This may differ
 *     from desiredName if the former has already been taken by the user.
 * @private
 */
Blockly.Degenerator.prototype.provideFunction_ = function(desiredName, code) {
  if (!this.definitions_[desiredName]) {
    var functionName =
        this.variableDB_.getDistinctName(desiredName, this.NAME_TYPE);
    this.functionNames_[desiredName] = functionName;
    this.definitions_[desiredName] = code.join('\n').replace(
        this.FUNCTION_NAME_PLACEHOLDER_REGEXP_, functionName);
  }
  return this.functionNames_[desiredName];
};
