/**
 * @license
 * Visual Blocks Language
 *
 * Copyright 2012 Google Inc.
 * https://blockly.googlecode.com/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Helper functions for generating JavaScript for blocks.
 * @author eric@legoaces.org (Eric Miller)
 */
'use strict';

goog.provide('Blockly.Degenerate.JavaScript');

goog.require('Blockly.Generator');

Blockly.Degenerate.JavaScript = new Blockly.Degenerator('JavaScript');

Blockly.Degenerate.JavaScript.setup = function(){
	var pats = Blockly.Degenerate.JavaScript.ePatterns
	pats = pats.concat(testAllInputs("math_arithmetic",{OP: 'ADD MINUS MULTIPLY DIVIDE POWER'.split(' ')}))
	pats = pats.concat(testAllInputs("math_single",{OP: 'ROOT ABS NEG LN LOG10 EXP POW10'.split(' ')}))
	pats = pats.concat(testAllInputs("math_constant",{CONSTANT: 'PI E GOLDEN_RATIO SQRT2 SQRT1_2 INFINITY'.split(' ')}))
	pats = pats.concat(testAllInputs("math_number_property",{PROPERTY: 'EVEN ODD WHOLE POSITIVE NEGATIVE DIVISIBLE_BY'.split(' ')})) //NOTE: PRIME is not in this list yet
	pats = pats.concat(testAllInputs("math_round",{OP: 'ROUND ROUNDUP ROUNDDOWN'.split(' ')}))
	pats = pats.concat(testAllInputs("math_modulo"))
	pats = pats.concat(testAllInputs("math_constrain"))
	//pats = pats.concat(testAllInputs("math_random_int")) //NOTE: does not fully work yet.
	pats = pats.concat(testAllInputs("math_random_float"))

	pats = pats.concat(testAllInputs("logic_compare",{OP: 'EQ NEQ LT LTE GT GTE'.split(' ')}))
	pats = pats.concat(testAllInputs("logic_operation",{OP: 'AND OR'.split(' ')}))
	pats = pats.concat(testAllInputs("logic_null"))
	pats = pats.concat(testAllInputs("logic_negate"))
	pats = pats.concat(testAllInputs("logic_ternary"))
	pats = pats.concat(testAllInputs("logic_boolean",{BOOL: 'TRUE FALSE'.split(' ')}))

	var isNum = function(n){
		var x = parseFloat(n)
		if (String(x) == n){
			return {match:n, bind:Blockly.JavaScript.ORDER_ATOMIC}
		}else{
			return false
		}
	}
	pats.push(isNum)

	var isStr = function(s){
		var str = false
		if (s[0] == '"' && Blockly.Degenerate.JavaScript.lenToMatch(s.slice(1), '"') == s.length - 2){
			str = s.slice(1, s.length-1)
		}
		if (s[0] == "'" && Blockly.Degenerate.JavaScript.lenToMatch(s.slice(1), "'") == s.length - 2){
			str = s.slice(1, s.length-1)
		}
		if (str != false) return {match:str, bind:Blockly.JavaScript.ORDER_ATOMIC}
		return false
	}
	pats.push(isStr)
	Blockly.Degenerate.JavaScript.ePatterns = pats
}
setTimeout(Blockly.Degenerate.JavaScript.setup, 0)

/* 
/**
 * Order of operation ENUMs.
 * https://developer.mozilla.org/en/JavaScript/Reference/Operators/Operator_Precedence
 *
Blockly.JavaScript.ORDER_ATOMIC = 0;         // 0 "" ...
Blockly.JavaScript.ORDER_MEMBER = 1;         // . []
Blockly.JavaScript.ORDER_NEW = 1;            // new
Blockly.JavaScript.ORDER_FUNCTION_CALL = 2;  // ()
Blockly.JavaScript.ORDER_INCREMENT = 3;      // ++
Blockly.JavaScript.ORDER_DECREMENT = 3;      // --
Blockly.JavaScript.ORDER_LOGICAL_NOT = 4;    // !
Blockly.JavaScript.ORDER_BITWISE_NOT = 4;    // ~
Blockly.JavaScript.ORDER_UNARY_PLUS = 4;     // +
Blockly.JavaScript.ORDER_UNARY_NEGATION = 4; // -
Blockly.JavaScript.ORDER_TYPEOF = 4;         // typeof
Blockly.JavaScript.ORDER_VOID = 4;           // void
Blockly.JavaScript.ORDER_DELETE = 4;         // delete
Blockly.JavaScript.ORDER_MULTIPLICATION = 5; // *
Blockly.JavaScript.ORDER_DIVISION = 5;       // /
Blockly.JavaScript.ORDER_MODULUS = 5;        // %
Blockly.JavaScript.ORDER_ADDITION = 6;       // +
Blockly.JavaScript.ORDER_SUBTRACTION = 6;    // -
Blockly.JavaScript.ORDER_BITWISE_SHIFT = 7;  // << >> >>>
Blockly.JavaScript.ORDER_RELATIONAL = 8;     // < <= > >=
Blockly.JavaScript.ORDER_IN = 8;             // in
Blockly.JavaScript.ORDER_INSTANCEOF = 8;     // instanceof
Blockly.JavaScript.ORDER_EQUALITY = 9;       // == != === !==
Blockly.JavaScript.ORDER_BITWISE_AND = 10;   // &
Blockly.JavaScript.ORDER_BITWISE_XOR = 11;   // ^Blockly.JavaScript.ORDER_BITWISE_OR = 12;    // |
Blockly.JavaScript.ORDER_LOGICAL_AND = 13;   // &&
Blockly.JavaScript.ORDER_LOGICAL_OR = 14;    // ||
Blockly.JavaScript.ORDER_CONDITIONAL = 15;   // ?:
Blockly.JavaScript.ORDER_ASSIGNMENT = 16;    // = += -= *= /= %= <<= >>= ...
Blockly.JavaScript.ORDER_COMMA = 17;         // ,
Blockly.JavaScript.ORDER_NONE = 99;          // (...)*/

/**
 * Arbitrary code to inject into locations that risk causing infinite loops.
 * Any instances of '%1' will be replaced by the block ID that failed.
 * E.g. '  checkTimeout(%1);\n'
 * @type ?string
 */
Blockly.Degenerate.JavaScript.INFINITE_LOOP_TRAP = null;

/**
 * Initialise the database of variable names.
 */
Blockly.Degenerate.JavaScript.init = function() {
  // Create a dictionary of definitions to be printed before the code.
  Blockly.Degenerate.JavaScript.definitions_ = Object.create(null);
  // Create a dictionary mapping desired function names in definitions_
  // to actual function names (to avoid collisions with user functions).
  Blockly.Degenerate.JavaScript.functionNames_ = Object.create(null);

  if (Blockly.Variables) {
    if (!Blockly.Degenerate.JavaScript.variableDB_) {
      Blockly.Degenerate.JavaScript.variableDB_ =
          new Blockly.Names(Blockly.Degenerate.JavaScript.RESERVED_WORDS_);
    } else {
      Blockly.Degenerate.JavaScript.variableDB_.reset();
    }

    var defvars = [];
    var variables = Blockly.Variables.allVariables();
    for (var x = 0; x < variables.length; x++) {
      defvars[x] = 'var ' +
          Blockly.Degenerate.JavaScript.variableDB_.getName(variables[x],
          Blockly.Variables.NAME_TYPE) + ';';
    }
    Blockly.Degenerate.JavaScript.definitions_['variables'] = defvars.join('\n');
  }
};

/**
 * Prepend the generated code with the variable definitions.
 * @param {string} code Generated code.
 * @return {string} Completed code.
 */
Blockly.Degenerate.JavaScript.finish = function(code) {
  // Convert the definitions dictionary into a list.
  var definitions = [];
  for (var name in Blockly.Degenerate.JavaScript.definitions_) {
    definitions.push(Blockly.Degenerate.JavaScript.definitions_[name]);
  }
  return definitions.join('\n\n') + '\n\n\n' + code;
};

/**
 * Naked values are top-level blocks with outputs that aren't plugged into
 * anything.  A trailing semicolon is needed to make this legal.
 * @param {string} line Line of generated code.
 * @return {string} Legal line of code.
 */
Blockly.Degenerate.JavaScript.scrubNakedValue = function(line) {
  return line + ';\n';
};

/**
 * Encode a string as a properly escaped JavaScript string, complete with
 * quotes.
 * @param {string} string Text to encode.
 * @return {string} JavaScript string.
 * @private
 */
Blockly.Degenerate.JavaScript.quote_ = function(string) {
  // TODO: This is a quick hack.  Replace with goog.string.quote
  string = string.replace(/\\/g, '\\\\')
                 .replace(/\n/g, '\\\n')
                 .replace(/'/g, '\\\'');
  return '\'' + string + '\'';
};

/**
 * Common tasks for generating JavaScript from blocks.
 * Handles comments for the specified block and any connected value blocks.
 * Calls any statements following this block.
 * @param {!Blockly.Block} block The current block.
 * @param {string} code The JavaScript code created for this block.
 * @return {string} JavaScript code with comments and subsequent blocks added.
 * @private
 */
Blockly.Degenerate.JavaScript.scrub_ = function(block, code) {
  if (code === null) {
    // Block has handled code generation itself.
    return '';
  }
  var commentCode = '';
  // Only collect comments for blocks that aren't inline.
  if (!block.outputConnection || !block.outputConnection.targetConnection) {
    // Collect comment for this block.
    var comment = block.getCommentText();
    if (comment) {
      commentCode += this.prefixLines(comment, '// ') + '\n';
    }
    // Collect comments for all value arguments.
    // Don't collect comments for nested statements.
    for (var x = 0; x < block.inputList.length; x++) {
      if (block.inputList[x].type == Blockly.INPUT_VALUE) {
        var childBlock = block.inputList[x].connection.targetBlock();
        if (childBlock) {
          var comment = this.allNestedComments(childBlock);
          if (comment) {
            commentCode += this.prefixLines(comment, '// ');
          }
        }
      }
    }
  }
  var nextBlock = block.nextConnection && block.nextConnection.targetBlock();
  var nextCode = this.blockToCode(nextBlock);
  return commentCode + code + nextCode;
};
